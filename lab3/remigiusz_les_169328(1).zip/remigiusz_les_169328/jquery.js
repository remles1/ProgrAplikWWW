$(".galleryimg").on("click", function(){
    $(this).toggleClass("galleryimgbig")
})